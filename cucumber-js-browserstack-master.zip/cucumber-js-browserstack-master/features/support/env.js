'use strict';

const { setDefaultTimeout } = require("@cucumber/cucumber");

setDefaultTimeout(60 * 1000);
